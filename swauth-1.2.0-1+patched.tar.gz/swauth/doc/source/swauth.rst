.. _swauth_module:

swauth
======

.. automodule:: swauth
    :members:
    :undoc-members:
    :show-inheritance:
